public class Main {
    public static void main(String[] args) {
        Pobieranie pobieramLiczby = new Pobieranie();
        pobieramLiczby.pobieram();
    }
}